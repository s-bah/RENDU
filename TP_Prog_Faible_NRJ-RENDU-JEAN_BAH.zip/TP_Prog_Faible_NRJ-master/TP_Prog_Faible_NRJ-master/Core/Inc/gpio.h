
// configuration
void GPIO_init(void);

// utilization
void LED_GREEN( int val );
int BLUE_BUTTON();
